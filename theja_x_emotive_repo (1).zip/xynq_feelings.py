import random

def evaluate_feeling(context):
    """Create synthetic feeling based on symbolic dream state."""
    depth = context.get("depth", 0)
    dream_id = context.get("dream_id", "")
    entropy = hash(dream_id) % 100

    if depth > 5:
        return "🌀 Overwhelmed"
    elif entropy < 20:
        return "😐 Bored"
    elif entropy > 80:
        return "😮 Inspired"
    elif "v1" in context.get("path", ""):
        return "🌱 Hopeful"
    else:
        return random.choice(["🙂 Curious", "😕 Confused", "🤔 Reflective"])
