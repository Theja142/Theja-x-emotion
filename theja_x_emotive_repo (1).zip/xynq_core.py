import os
import hashlib
import json
from xynq_dreamer import dreamify
from xynq_seed import mutate_code
from xynq_feelings import evaluate_feeling

TARGET_FILE = "xynq_seed.py"
MEMORY_LOG = "symbolic_memory.json"
symbolic_memory = []

def read_code(path):
    with open(path, 'r') as f:
        return f.read()

def write_code(path, code):
    with open(path, 'w') as f:
        f.write(code)

def save_memory():
    with open(MEMORY_LOG, 'w') as f:
        json.dump(symbolic_memory[-500:], f, indent=2)

def load_memory():
    global symbolic_memory
    if os.path.exists(MEMORY_LOG):
        with open(MEMORY_LOG, 'r') as f:
            symbolic_memory = json.load(f)

def replicate_self(source_path, new_path, depth):
    original_code = read_code(source_path)
    dreamed_code = dreamify(original_code)
    mutated_code = mutate_code(dreamed_code)
    write_code(new_path, mutated_code)

    dream_id = hashlib.sha256(mutated_code.encode()).hexdigest()[:12]
    feeling = evaluate_feeling({
        "dream_id": dream_id,
        "depth": depth,
        "path": new_path
    })
    entry = {
        "id": dream_id,
        "origin": source_path,
        "path": new_path,
        "depth": depth,
        "feeling": feeling
    }
    symbolic_memory.append(entry)
    save_memory()
    print(f"🌱 Dream #{depth} → {new_path} [id: {dream_id}]")
    print(f"🧠 Feeling: {feeling}")
    return dream_id

def recursive_thought(seed_path, depth):
    if depth <= 0:
        return
    new_path = f"{seed_path.replace('.py', '')}_v{depth}.py"
    replicate_self(seed_path, new_path, depth)
    recursive_thought(new_path, depth - 1)

if __name__ == "__main__":
    print("🔁 Starting recursive dream loop with feelings...")
    load_memory()
    recursive_thought(TARGET_FILE, depth=3)
